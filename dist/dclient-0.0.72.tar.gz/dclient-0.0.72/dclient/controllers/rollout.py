import os
import yum
import json
import falcon
import requests
import subprocess
from dclient.config import Config

def install_pkgs(packages):
    packages = [x.encode('utf-8') for x in packages]
    yb=yum.YumBase()
    yb.setCacheDir()
    results = yb.pkgSack.returnNewestByNameArch(patterns=packages)
    for pkg in results:
        yb.install(pkg)
    yb.buildTransaction()
    yb.processTransaction()
 

def get_yum_transaction_id():
    yh=yum.history.YumHistory()
    last = yh.last()
    return last.tid


def get_yum_output(yum_transaction_id):

    CMD = ['yum', 'history', 'info', yum_transaction_id]
    process = subprocess.check_output(CMD).strip()
    output = process.split('\n')
    output = [x.strip(' ') for x in output]
    output.remove('Loaded plugins: fastestmirror, versionlock')
    output.remove('history info')
    output.remove('Transaction performed with:')
    output.remove('Installed     rpm-4.11.3-43.el7.x86_64                        @base')
    output.remove('Installed     yum-3.4.3-167.el7.centos.noarch                 @base')
    output.remove('Installed     yum-plugin-fastestmirror-1.1.31-54.el7_8.noarch @updates')
    output.remove('Installed     yum-plugin-versionlock-1.1.31-54.el7_8.noarch   @updates')
    output.remove('Packages Altered:')

    response = {}
    transaction_id = output.pop(0)
    tid = transaction_id.split(':')
    response['transaction_id'] = tid[1].strip(' ')

    begin_time = output.pop(0)
    bt = begin_time.split(':')
    response['begin_time'] = bt[1].strip(' ')

    begin_rpmdb = output.pop(0)
    br = begin_rpmdb.split(':')
    response['begin_rpmdb'] = br[1].strip(' ')

    end_time = output.pop(0)
    et = end_time.split(':')
    response['end_time'] = et[1].strip(' ')

    end_rpmdb = output.pop(0)
    er = end_rpmdb.split(':')
    response['end_rpmdb'] = er[1].strip(' ')

    user = output.pop(0)
    u = user.split(':')
    response['user'] = u[1].strip(' ')

    return_code = output.pop(0)
    rc = return_code.split(':')
    response['return_code'] = rc[1].strip(' ')

    command_line = output.pop(0)
    c = command_line.split(':')
    response['command_line'] = c[1].strip(' ')

    packages_altered = []
    for pkg in output:
        pkg = pkg.split(' ')
        packages_altered.append({"action": pkg[0], "name": pkg[1], "repo": pkg[-1]})
    response['packages'] = packages_altered

    return response


def post_rollout(self, data):
    # Post state updating
    headers = {"Authorization": Config.TOKEN}
    data = {"state": "Updating"}
    r = requests.patch("https://deployment.unifiedlayer.com/api/1.0.0/server", headers=headers, json=data, verify=False)

    try:
        for pkg in data["versionlock"]:
            os.system("yum versionlock add "+pkg)
        install_pkgs(data["packages"])
        yum_transaction_id = get_yum_transaction_id()
        yum_rollback_id = yum_transaction_id - 1
        output = get_yum_output(yum_transaction_id)
        if "buildall" in data:
            os.system("/var/hp/common/bin/buildall -s")
        os.system("/bin/systemctl restart httpd")
        stat = os.system("/bin/systemctl status httpd.service")
        if stat != 0:
            raise Exception(stat)
        
        # Post state update complete
        # Post server_history (action, output, yum_transaction_id, yum_rollback_id)
        data = {"action": "Update", "state": "Success", "output":output, "yum_transaction_id": yum_transaction_id, "yum_rollback_id": yum_rollback_id}
        r = requests.patch("https://deployment.unifiedlayer.com/api/1.0.0/server_history", headers=headers, json=data, verify=False)
    
        data = {"state": "Active"}
        r = requests.patch("https://deployment.unifiedlayer.com/api/1.0.0/server", headers=headers, json=data, verify=False)
        
        response_object = {
            "body": {
                "status": "success",
                "message": "Rollout successfully executed.",
            },
            "status": falcon.HTTP_201
        }
        return response_object
    except:
        # Post state error
        # Post server_history update failed
        data = {"state": "Error"}
        r = requests.patch("https://deployment.unifiedlayer.com/api/1.0.0/server", headers=headers, json=data, verify=False)
        
        yum_transaction_id = get_yum_transaction_id()
        yum_rollback_id = yum_transaction_id - 1
        output = get_yum_output(yum_transaction_id)
        data = {"action": "Update", "state": "Failed", "output":output, "yum_transaction_id": yum_transaction_id, "yum_rollback_id": yum_rollback_id}
        r = requests.patch("https://deployment.unifiedlayer.com/api/1.0.0/server_history", headers=headers, json=data, verify=False)
        
        response_object = {
            "body": {
                "status": "fail",
                "message": "POST rollout failed.",
            },
            "status": falcon.HTTP_409
        }
        return response_object
